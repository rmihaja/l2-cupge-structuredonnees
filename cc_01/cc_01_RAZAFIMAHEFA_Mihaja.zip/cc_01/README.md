# Structure de données : CC1

To run the `main` program, type the command :

```bash
make run
```